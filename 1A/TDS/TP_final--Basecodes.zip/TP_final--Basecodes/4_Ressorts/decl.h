#ifndef DECL_H_INCLUDED
#define DECL_H_INCLUDED

#define NB_BALLES 25

#endif // DECL_H_INCLUDED
