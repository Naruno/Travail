#ifndef DECL_H_INCLUDED
#define DECL_H_INCLUDED

#define NB_BALLES 3
#define NB_ATTRACTEURS 1

#endif // DECL_H_INCLUDED
