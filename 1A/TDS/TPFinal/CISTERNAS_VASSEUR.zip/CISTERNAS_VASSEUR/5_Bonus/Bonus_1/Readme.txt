Ce Bonus est le Programme 2_Rebonds permettant la modification du coefficient d'attenuation directement dans le fichier balle.txt

Son fonctionnement est la même que pour 2_Rebonds