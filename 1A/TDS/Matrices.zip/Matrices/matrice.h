#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
typedef struct Matrice_s{
	
	int height;	   // Contient le nombre de lignes de la matrice
	int width;	   // Contient le nombre de colonnes de la matrice
	double **M; // Tableau contenant les coefficients de la matrice	
}Matrice;

Matrice *AllocMatrice(int width, int height); // Permet de charger une matrice de taille n*p à partir d'un fichier de configuration
Matrice *ChargerMatrice (char *path);
int EcrireMatrice (char*path, Matrice *m);
int AfficherMatrice(Matrice *m); // Permet d'afficher une matrice
void EchelonnerMatrice(Matrice *m); // Permet d'échelonner et réduire une matrice grâce à la méthode Gauss-Jordan
void LibererMatrice(Matrice *m); // Permet de libérer l'espace mémoire alloué à la matrice
