#include "matrice.h"

int main(int argc, char **argv)
{
	if(argc>2){
		Matrice *matrice;
		
		matrice=ChargerMatrice(argv[1]);
			
		AfficherMatrice(matrice);
		//EchelonnerMatrice(&matrice);
		EcrireMatrice(argv[2],matrice);
		AfficherMatrice(matrice);
		LibererMatrice(matrice);																								
	}
	else{
		printf("Il manque le fichier \"matrice.txt\"");
		return 0;
	}	
	return 0;
}
